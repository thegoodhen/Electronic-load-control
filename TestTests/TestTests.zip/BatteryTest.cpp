#include "BatteryTest.h"

void BatteryTest::setFirstScheduledStartTime(int day, int month, int year, int hour, int min)
{
	
	year = CalendarYrToTm(year);
	tmElements_t startDateElems = { 0,min,hour,1, day,month,year};
	this->firstScheduledStartTime = makeTime(startDateElems);
	this->scheduledStartTime = this->firstScheduledStartTime;
	Serial.println("scheduled start time set...");
}

void BatteryTest::setSchedulingPeriod(int days, int hours, int minutes)
{
	tmElements_t periodElems = { 0,minutes,hours,1, days+1, 1, 0};
	this->period = makeTime(periodElems);
}