// 
// 
// 

#include "SpiffsPersistentSettingsUtils.h"

void SpiffsPersistentSettingsUtils::begin()
{
	SPIFFS.begin();
}

JsonObject& SpiffsPersistentSettingsUtils::loadSettings(char * filename)
{
	File f = SPIFFS.open(filename, "r");
	String s=f.readStringUntil(0);
	f.close();

	StaticJsonBuffer<1000> jb;
	JsonObject& obj = jb.parseObject(s);
	return obj;
}

void SpiffsPersistentSettingsUtils::saveSettings(JsonObject& obj, char * filename)
{
	File f = SPIFFS.open(filename, "w");
	char buff[1000];
	obj.printTo(buff);
	f.print(buff);
	f.write(0);
	f.close();
}
